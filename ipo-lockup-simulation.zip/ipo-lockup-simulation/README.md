# Insider Ownership Concentration and Post-Lockup Expiration Price Decay in IPO Markets
### An Agent-Based Simulation Study

**Author:** Vishaal O  
**Status:** Under review — Journal of Emerging Investigators (JEI)  
**Language:** Python 3.10+  
**Method:** Agent-Based Simulation (Mesa 3.x)

---

## Overview

This repository contains the complete simulation code, results, and figures for the research paper:

> *"Insider Ownership Concentration and Post-Lockup Expiration Price Decay in IPO Markets: An Agent-Based Simulation Approach"*

### Research Question
Does higher insider ownership concentration — measured by the Herfindahl-Hirschman Index (HHI) — cause greater post-lockup expiration price decay in IPO markets, independent of total insider ownership levels?

### Key Finding
Yes. The simulation demonstrates a strong, statistically significant negative relationship between insider ownership concentration and post-lockup stock price performance (R² = 0.9936, p = 0.0002). A company with all insider shares held by one person experiences a **44% larger price drop** at lockup expiration than one where the same shares are spread across 20 insiders.

---

## Results at a Glance

| Scenario | Insiders | HHI | SAR Mean | SAR Std |
|----------|----------|-----|----------|---------|
| S1 — Very Low  | 20 | 0.050 | −2.097% | 0.099% |
| S2 — Low       | 10 | 0.100 | −2.094% | 0.152% |
| S3 — Medium    |  5 | 0.250 | −2.293% | 0.221% |
| S4 — High      |  2 | 0.517 | −2.601% | 0.351% |
| S5 — Very High |  1 | 1.000 | −3.030% | 0.409% |

**OLS Regression:** SAR = −2.033% − 1.017% × HHI  
**R² = 0.9936 | p = 0.0002 | S1 vs S5 t-test: t = 31.3, p ≈ 0**

---

## Repository Structure

```
ipo-lockup-simulation/
│
├── simulation/
│   ├── agents.py        # InsiderAgent, RetailTraderAgent, MarketMakerAgent
│   ├── model.py         # IPOMarketModel — core simulation engine
│   ├── experiment.py    # Runs all 5 scenarios × 200 iterations
│   └── analysis.py      # Statistical analysis + figure generation
│
├── results/
│   └── summary_table.csv   # Full numerical results table
│
├── figures/
│   ├── fig1_sar_by_scenario.png   # Main result: SAR by concentration
│   ├── fig2_price_paths.png       # Average price trajectories
│   ├── fig3_sar_distribution.png  # Box plots of SAR distributions
│   ├── fig4_regression.png        # OLS regression: SAR ~ HHI
│   └── fig5_pre_post.png          # Pre vs post expiration price levels
│
├── requirements.txt
└── README.md
```

---

## How to Reproduce

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the full experiment (all 5 scenarios × 200 iterations)
```bash
cd simulation
python experiment.py
```
This takes approximately 8–10 minutes and saves results to `results/simulation_results.pkl` and `results/summary_table.csv`.

### 3. Generate all figures and statistical output
```bash
python analysis.py
```
This produces all 5 figures in `figures/` and prints the full statistical summary including regression coefficients and pairwise t-tests.

### 4. Run a single scenario quickly (for testing)
```python
from model import IPOMarketModel

model = IPOMarketModel(
    concentration_hhi    = 0.52,   # Try: 0.05, 0.10, 0.25, 0.52, 1.00
    n_insiders           = 2,
    total_insider_shares = 300_000,
    n_retail_traders     = 150,
    ipo_price            = 20.0,
    fundamental_value    = 22.0,
    seed                 = 42
)
model.run()
print(f"Simulated Abnormal Return: {model.get_abnormal_return()*100:.3f}%")
print(f"Actual HHI: {model.simulated_hhi:.4f}")
```

---

## Simulation Design

### Agents

**InsiderAgent**  
Holds locked-up shares. Cannot sell before day 220 (lockup expiration = IPO day 40 + 180 days). At expiration, decides to sell based on a sell urgency parameter derived from their ownership fraction. Sells a partial block drawn from a Beta distribution.

**RetailTraderAgent (×150)**  
Heterogeneous in sentiment, momentum-following tendency, lockup awareness, and contrarian disposition. Generates buy/sell orders each day based on:
- Recent price momentum
- Proximity to lockup expiration (fear signal, scaled by insider concentration)
- Herding: amplified if recent order flow is sell-dominated

**MarketMakerAgent**  
Sets price each step via order imbalance. Applies a concentration-scaled amplifier to insider block sales — capturing the real-world phenomenon that large block sales cause disproportionate price impact.

### Key Parameters

| Parameter | Value |
|-----------|-------|
| Simulation length | 230 days (40 pre-IPO + 190 trading days) |
| Lockup expiration | Day 220 (180 days post-IPO) |
| Total shares | 1,000,000 |
| Insider ownership | 30% (300,000 shares) |
| IPO price | $20.00 |
| Fundamental value | $22.00 |
| Retail traders | 150 |
| Iterations per scenario | 200 |

### Measuring the Effect: Simulated Abnormal Return (SAR)

SAR is calculated as the actual return in the ±2 day event window around lockup expiration, minus the expected return based on a baseline period (days −20 to −10 before expiration):

```
SAR = Actual Return (event window) − Expected Return (baseline × window length)
```

This mirrors the event study methodology used in empirical lockup expiration research (Field & Hanka, 2001).

---

## Key References

- Field, L. C., & Hanka, G. (2001). The expiration of IPO share lockups. *Journal of Finance*, 56(2), 471–500.
- Brav, A., & Gompers, P. A. (2003). The role of lockups in initial public offerings. *Review of Financial Studies*, 16(1), 1–29.
- Tesfatsion, L., & Judd, K. L. (Eds.). (2006). *Handbook of Computational Economics, Vol. 2: Agent-Based Computational Economics*. North-Holland.

---

## License

MIT License — free to use, reproduce, and build upon with attribution.

---

*For questions or correspondence, open a GitHub Issue on this repository.*
