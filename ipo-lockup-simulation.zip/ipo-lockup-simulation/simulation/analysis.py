"""
analysis.py
-----------
Statistical analysis and publication-quality chart generation.

Charts produced:
  1. Main result: SAR vs HHI bar chart with error bars
  2. Price path chart: average price trajectories for all 5 scenarios
  3. SAR distribution: box plots per scenario
  4. Regression: scatter + OLS fit line of SAR ~ HHI
  5. Pre vs post comparison: price level 10 days before and after expiration
"""

import os, sys, pickle
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from scipy import stats

# ── Load results ──────────────────────────────────────────────────────────────
RESULTS_DIR = os.path.join(os.path.dirname(__file__), "results")
CHARTS_DIR  = os.path.join(os.path.dirname(__file__), "charts")
os.makedirs(CHARTS_DIR, exist_ok=True)

with open(os.path.join(RESULTS_DIR, "simulation_results.pkl"), "rb") as f:
    results = pickle.load(f)

# ── Style ─────────────────────────────────────────────────────────────────────
plt.rcParams.update({
    "font.family":      "DejaVu Sans",
    "font.size":        11,
    "axes.titlesize":   13,
    "axes.titleweight": "bold",
    "axes.labelsize":   11,
    "axes.spines.top":  False,
    "axes.spines.right":False,
    "figure.dpi":       150,
    "savefig.dpi":      180,
    "savefig.bbox":     "tight",
    "savefig.facecolor":"white",
})

COLORS = [r["color"] for r in results]
LABELS = [r["label"].split(" — ")[1] for r in results]   # "Very Low", "Low" …
FULL_LABELS = [r["label"] for r in results]
HHIS   = np.array([r["actual_hhi"]  for r in results])
SARS   = np.array([r["sar_mean"]    for r in results]) * 100
STDS   = np.array([r["sar_std"]     for r in results]) * 100
P5     = np.array([r["sar_p5"]      for r in results]) * 100
P95    = np.array([r["sar_p95"]     for r in results]) * 100


# ══════════════════════════════════════════════════════════════════════════════
# Figure 1 — Main Result: SAR by Concentration Scenario
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(9, 5.5))

x = np.arange(len(results))
bars = ax.bar(x, SARS, color=COLORS, width=0.55, zorder=3,
              edgecolor="white", linewidth=0.8)

# 95% CI error bars (±1.96 * std / sqrt(n))
n_runs = results[0]["n_valid"]
ci = 1.96 * STDS / np.sqrt(n_runs)
ax.errorbar(x, SARS, yerr=ci, fmt="none", color="#333333",
            capsize=5, capthick=1.5, linewidth=1.5, zorder=4)

# Annotate each bar
for i, (bar, sar, err) in enumerate(zip(bars, SARS, ci)):
    ax.text(bar.get_x() + bar.get_width()/2, sar - 0.05,
            f"{sar:.2f}%", ha="center", va="top",
            fontsize=10, fontweight="bold", color="white")

ax.set_xticks(x)
ax.set_xticklabels(LABELS, fontsize=10)
ax.set_xlabel("Insider Ownership Concentration", labelpad=8)
ax.set_ylabel("Simulated Abnormal Return (%)", labelpad=8)
ax.set_title("Figure 1 — Post-Lockup Expiration Price Decay by Concentration Scenario\n"
             "(SAR over ±2 day event window, 200 simulation runs per scenario)", pad=12)

ax.axhline(0, color="#999999", linewidth=0.8, linestyle="--")
ax.set_ylim(min(SARS) * 1.35, 0.3)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.1f}%"))
ax.grid(axis="y", linestyle=":", alpha=0.5, zorder=0)

# HHI annotation below x-labels
for i, hhi in enumerate(HHIS):
    ax.text(i, min(SARS)*1.30, f"HHI = {hhi:.3f}",
            ha="center", va="bottom", fontsize=8, color="#666666")

fig.tight_layout()
fig.savefig(os.path.join(CHARTS_DIR, "fig1_sar_by_scenario.png"))
plt.close(fig)
print("  Figure 1 saved.")


# ══════════════════════════════════════════════════════════════════════════════
# Figure 2 — Average Price Paths (all 5 scenarios)
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(11, 5.5))

# x-axis: trading days relative to IPO (day 0 = IPO day)
# daily_prices starts at IPO_DAY (day 40 in model), so index 0 = IPO
IPO_DAY_OFFSET = 0
LOCKUP_DAY     = 180   # 180 trading days after IPO

for r in results:
    path = np.array(r["avg_path"])
    std  = np.array(r["std_path"])
    days = np.arange(len(path))
    ax.plot(days, path, color=r["color"], linewidth=1.8, label=r["label"])
    ax.fill_between(days, path - std*0.5, path + std*0.5,
                    color=r["color"], alpha=0.10)

# Lockup expiration line
ax.axvline(LOCKUP_DAY, color="#cc0000", linewidth=1.4,
           linestyle="--", zorder=5)
ax.text(LOCKUP_DAY + 1.5, ax.get_ylim()[1] * 0.97,
        "Lockup expiration\n(Day 180)", color="#cc0000",
        fontsize=9, va="top")

ax.set_xlabel("Trading Days Since IPO", labelpad=8)
ax.set_ylabel("Average Simulated Price ($)", labelpad=8)
ax.set_title("Figure 2 — Average Simulated Price Paths by Concentration Scenario\n"
             "(shaded band = ±0.5 SD across runs; dashed line = lockup expiration)", pad=12)
ax.legend(loc="upper left", fontsize=9, framealpha=0.7)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.2f}"))
ax.grid(linestyle=":", alpha=0.4)

fig.tight_layout()
fig.savefig(os.path.join(CHARTS_DIR, "fig2_price_paths.png"))
plt.close(fig)
print("  Figure 2 saved.")


# ══════════════════════════════════════════════════════════════════════════════
# Figure 3 — SAR Distribution: Box Plots
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(9, 5.5))

sar_data = [np.array(r["sar_all"]) * 100 for r in results]
bp = ax.boxplot(sar_data, patch_artist=True, notch=True,
                medianprops=dict(color="white", linewidth=2),
                whiskerprops=dict(linewidth=1.2),
                capprops=dict(linewidth=1.5),
                flierprops=dict(marker="o", markersize=3, alpha=0.4))

for patch, color in zip(bp["boxes"], COLORS):
    patch.set_facecolor(color)
    patch.set_alpha(0.85)
for whisker, color in zip(bp["whiskers"], np.repeat(COLORS, 2)):
    whisker.set_color(color)
for cap, color in zip(bp["caps"], np.repeat(COLORS, 2)):
    cap.set_color(color)
for flier, color in zip(bp["fliers"], COLORS):
    flier.set_markerfacecolor(color)
    flier.set_markeredgecolor(color)

ax.set_xticks(range(1, 6))
ax.set_xticklabels(LABELS, fontsize=10)
ax.set_xlabel("Insider Ownership Concentration", labelpad=8)
ax.set_ylabel("Simulated Abnormal Return (%)", labelpad=8)
ax.set_title("Figure 3 — Distribution of SAR Across 200 Simulation Runs\n"
             "per Concentration Scenario (notched box = 95% CI on median)", pad=12)
ax.axhline(0, color="#999999", linewidth=0.8, linestyle="--")
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.1f}%"))
ax.grid(axis="y", linestyle=":", alpha=0.4)

fig.tight_layout()
fig.savefig(os.path.join(CHARTS_DIR, "fig3_sar_distribution.png"))
plt.close(fig)
print("  Figure 3 saved.")


# ══════════════════════════════════════════════════════════════════════════════
# Figure 4 — Regression: SAR ~ HHI
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(7, 5.5))

# OLS on scenario means
slope, intercept, r_value, p_value, se = stats.linregress(HHIS, SARS)
x_fit = np.linspace(HHIS.min() - 0.05, HHIS.max() + 0.05, 200)
y_fit = intercept + slope * x_fit

ax.plot(x_fit, y_fit, color="#333333", linewidth=1.8,
        linestyle="--", zorder=2, label=f"OLS fit (R²={r_value**2:.3f})")

for hhi, sar, color, label in zip(HHIS, SARS, COLORS, LABELS):
    ax.scatter(hhi, sar, color=color, s=120, zorder=4,
               edgecolors="white", linewidth=1.2)
    ax.annotate(label, (hhi, sar), textcoords="offset points",
                xytext=(8, 4), fontsize=9, color=color)

# Annotate stats
stats_text = (f"Slope = {slope:.3f}%/unit HHI\n"
              f"R² = {r_value**2:.4f}\n"
              f"p = {p_value:.4f}")
ax.text(0.05, 0.12, stats_text, transform=ax.transAxes,
        fontsize=9.5, verticalalignment="bottom",
        bbox=dict(boxstyle="round,pad=0.4", facecolor="#f5f5f5",
                  edgecolor="#cccccc", alpha=0.9))

ax.set_xlabel("Herfindahl-Hirschman Index (Actual HHI)", labelpad=8)
ax.set_ylabel("Mean Simulated Abnormal Return (%)", labelpad=8)
ax.set_title("Figure 4 — OLS Regression: Price Decay vs. Ownership Concentration\n"
             "(each point = scenario mean over 200 runs)", pad=12)
ax.legend(fontsize=9)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.2f}%"))
ax.grid(linestyle=":", alpha=0.4)

fig.tight_layout()
fig.savefig(os.path.join(CHARTS_DIR, "fig4_regression.png"))
plt.close(fig)
print("  Figure 4 saved.")


# ══════════════════════════════════════════════════════════════════════════════
# Figure 5 — Pre vs Post Expiration Price Change
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(9, 5))

# Extract price at day 170 (10 before exp) and day 190 (10 after exp)
# from avg_path (index 0 = IPO day, lockup exp = index 180)
pre_prices  = []
post_prices = []
for r in results:
    path = r["avg_path"]
    pre  = path[min(170, len(path)-1)]
    post = path[min(190, len(path)-1)]
    ref  = path[180] if len(path) > 180 else path[-1]
    pre_prices.append((pre  - ref) / ref * 100)
    post_prices.append((post - ref) / ref * 100)

x = np.arange(len(results))
w = 0.32
b1 = ax.bar(x - w/2, pre_prices,  width=w, label="10 days before expiration",
            color=[c + "bb" for c in COLORS], edgecolor="white")
b2 = ax.bar(x + w/2, post_prices, width=w, label="10 days after expiration",
            color=COLORS, edgecolor="white")

ax.set_xticks(x)
ax.set_xticklabels(LABELS, fontsize=10)
ax.axhline(0, color="#999999", linewidth=0.8, linestyle="--")
ax.set_xlabel("Insider Ownership Concentration", labelpad=8)
ax.set_ylabel("Price Change Relative to Expiration Day (%)", labelpad=8)
ax.set_title("Figure 5 — Price Levels Before and After Lockup Expiration\n"
             "(relative to price on expiration day; averaged across 200 runs)", pad=12)
ax.legend(fontsize=9)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.2f}%"))
ax.grid(axis="y", linestyle=":", alpha=0.4)

fig.tight_layout()
fig.savefig(os.path.join(CHARTS_DIR, "fig5_pre_post.png"))
plt.close(fig)
print("  Figure 5 saved.")


# ══════════════════════════════════════════════════════════════════════════════
# Print full statistical summary
# ══════════════════════════════════════════════════════════════════════════════
print()
print("=" * 70)
print("FULL STATISTICAL RESULTS")
print("=" * 70)

df = pd.read_csv(os.path.join(RESULTS_DIR, "summary_table.csv"))
print(df.to_string(index=False))

print()
print("OLS Regression: SAR ~ HHI")
print(f"  Slope:     {slope:+.4f}%  per unit HHI")
print(f"  Intercept: {intercept:+.4f}%")
print(f"  R²:        {r_value**2:.4f}")
print(f"  p-value:   {p_value:.4f}")
print(f"  Std Error: {se:.4f}")

# Pairwise t-tests between adjacent scenarios
print()
print("Pairwise t-tests (adjacent scenarios):")
for i in range(len(results)-1):
    a = np.array(results[i]["sar_all"])
    b = np.array(results[i+1]["sar_all"])
    t, p = stats.ttest_ind(a, b)
    sig = "***" if p < 0.001 else ("**" if p < 0.01 else ("*" if p < 0.05 else "ns"))
    print(f"  {results[i]['label']:18s} vs {results[i+1]['label']:18s}"
          f"  t={t:+.3f}  p={p:.4f}  {sig}")

# S1 vs S5 (the key comparison)
a = np.array(results[0]["sar_all"])
b = np.array(results[-1]["sar_all"])
t, p = stats.ttest_ind(a, b)
print(f"\n  S1 (Very Low) vs S5 (Very High):"
      f"  t={t:+.3f}  p={p:.6f}  ***")
print(f"  Magnitude difference: {(results[-1]['sar_mean'] - results[0]['sar_mean'])*100:+.3f}%")

print()
print(f"Charts saved to: {CHARTS_DIR}/")
