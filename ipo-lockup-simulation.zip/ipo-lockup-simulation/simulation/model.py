"""
model.py — Mesa 3.x compatible IPO Market Model (tuned parameters)
"""
import numpy as np
from mesa import Model
from agents import InsiderAgent, RetailTraderAgent, MarketMakerAgent


def _allocate_shares_by_hhi(n_insiders, total_shares, target_hhi, rng):
    if n_insiders == 1:
        return [total_shares]
    min_hhi = 1.0 / n_insiders
    if target_hhi <= min_hhi + 0.005:
        base   = total_shares // n_insiders
        extras = total_shares - base * n_insiders
        alloc  = [base + (1 if i < extras else 0) for i in range(n_insiders)]
        rng.shuffle(alloc)
        return alloc

    def sample_hhi(alpha):
        vals = [float(np.sum(rng.dirichlet([alpha]*n_insiders)**2)) for _ in range(200)]
        return float(np.mean(vals))

    lo, hi = 0.01, 20.0
    for _ in range(30):
        mid = (lo + hi) / 2
        if sample_hhi(mid) < target_hhi:
            hi = mid
        else:
            lo = mid
    fracs = rng.dirichlet([(lo+hi)/2] * n_insiders)
    raw   = (fracs * total_shares).astype(int)
    raw[0] += total_shares - int(raw.sum())
    return raw.tolist()


class IPOMarketModel(Model):
    IPO_DAY           = 40
    LOCKUP_EXPIRATION = 220
    TOTAL_DAYS        = 230

    def __init__(self, concentration_hhi=0.10, n_insiders=10,
                 total_insider_shares=300_000, n_retail_traders=150,
                 ipo_price=20.0, fundamental_value=22.0, seed=None):
        rng_arg = np.random.default_rng(seed)
        super().__init__(rng=rng_arg)

        self.concentration_hhi    = concentration_hhi
        self.total_insider_shares = total_insider_shares
        self.ipo_price            = ipo_price
        self.fundamental_value    = fundamental_value

        self.current_day   = 0
        self.current_price = ipo_price
        self.price_history = [ipo_price] * self.IPO_DAY

        self.buy_orders:         list = []
        self.sell_orders:        list = []
        self.recent_order_types: list = []
        self.daily_prices:       list = []

        rng = np.random.default_rng(seed)

        alloc = _allocate_shares_by_hhi(n_insiders, total_insider_shares,
                                        concentration_hhi, rng)
        for shares in alloc:
            frac    = shares / total_insider_shares
            urgency = float(np.clip(0.3 + frac*2.0 + rng.normal(0, 0.1), 0.1, 0.95))
            InsiderAgent(self, shares_held=int(shares), sell_urgency=urgency)

        for _ in range(n_retail_traders):
            RetailTraderAgent(
                self,
                wealth           = int(rng.integers(500, 5000)),
                sentiment_bias   = float(rng.uniform(-0.3, 0.5)),
                momentum_weight  = float(rng.uniform(0.1, 0.8)),
                lockup_awareness = float(rng.uniform(0.2, 1.0)),
                contrarian       = float(rng.beta(1.5, 4)),
            )

        # Tuned: spread=0.00005 keeps prices in realistic range
        MarketMakerAgent(self, spread=0.00005, reversion_strength=0.02)

    def step(self):
        if self.current_day < self.IPO_DAY:
            self.current_day += 1
            return
        self.agents.shuffle_do("step")
        self.daily_prices.append(self.current_price)
        self.current_day += 1

    def run(self):
        for _ in range(self.TOTAL_DAYS):
            self.step()

    @property
    def simulated_hhi(self):
        ins   = self.agents_by_type[InsiderAgent]
        total = sum(a.shares_held for a in ins)
        if total == 0:
            return 0.0
        return float(sum((a.shares_held/total)**2 for a in ins))

    def get_abnormal_return(self, window=5):
        exp_idx = self.LOCKUP_EXPIRATION - self.IPO_DAY  # = 180
        if exp_idx >= len(self.daily_prices):
            return float("nan")
        bl_start = max(0, exp_idx - 20)
        bl_end   = max(0, exp_idx - 10)
        if bl_end <= bl_start:
            return float("nan")
        bp = self.daily_prices[bl_start:bl_end+1]
        if len(bp) < 2:
            return float("nan")
        avg_bl = float(np.mean([(bp[i]-bp[i-1])/bp[i-1] for i in range(1, len(bp))]))
        ev_s   = max(0, exp_idx - 2)
        ev_e   = min(len(self.daily_prices)-1, exp_idx + 2)
        actual = (self.daily_prices[ev_e] - self.daily_prices[ev_s]) / self.daily_prices[ev_s]
        return float(actual - avg_bl * (ev_e - ev_s))
